const { Events, EmbedBuilder } = require("discord.js");
const config = require("../config.json");

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(member) {
    if (!config.welcomeChannelId || config.welcomeChannelId === "ISI_ID_CHANNEL_WELCOME") return;

    const channel = member.guild.channels.cache.get(config.welcomeChannelId);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(0x00ff99)
      .setTitle("👋 Selamat Datang!")
      .setDescription(`Halo ${member}, selamat datang di **${member.guild.name}**!\nSekarang kita ada **${member.guild.memberCount}** member.`)
      .setThumbnail(member.user.displayAvatarURL())
      .setTimestamp();

    channel.send({ embeds: [embed] }).catch(() => {});
  },
};
