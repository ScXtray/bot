const { Events } = require("discord.js");
const config = require("../config.json");

async function handleReaction(reaction, user, isAdd) {
  if (user.bot) return;
  if (reaction.message.id !== config.reactRole.messageId) return;

  // Kalau reaction dari pesan lama (partial), fetch dulu biar data lengkap
  if (reaction.partial) {
    try {
      await reaction.fetch();
    } catch {
      return;
    }
  }

  const emoji = reaction.emoji.name;
  const roleId = config.reactRole.emojiRoleMap[emoji];
  if (!roleId) return;

  const guild = reaction.message.guild;
  const member = await guild.members.fetch(user.id).catch(() => null);
  const role = guild.roles.cache.get(roleId);
  if (!member || !role) return;

  if (isAdd) {
    await member.roles.add(role).catch(() => {});
  } else {
    await member.roles.remove(role).catch(() => {});
  }
}

module.exports = [
  {
    name: Events.MessageReactionAdd,
    async execute(reaction, user) {
      await handleReaction(reaction, user, true);
    },
  },
  {
    name: Events.MessageReactionRemove,
    async execute(reaction, user) {
      await handleReaction(reaction, user, false);
    },
  },
];
