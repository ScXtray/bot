const { Events, EmbedBuilder } = require("discord.js");
const config = require("../config.json");

module.exports = {
  name: Events.GuildMemberRemove,
  async execute(member) {
    if (!config.leaveChannelId || config.leaveChannelId === "ISI_ID_CHANNEL_LEAVE") return;

    const channel = member.guild.channels.cache.get(config.leaveChannelId);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(0xff6666)
      .setTitle("👋 Sampai Jumpa")
      .setDescription(`**${member.user.tag}** telah meninggalkan server.\nSekarang tersisa **${member.guild.memberCount}** member.`)
      .setThumbnail(member.user.displayAvatarURL())
      .setTimestamp();

    channel.send({ embeds: [embed] }).catch(() => {});
  },
};
