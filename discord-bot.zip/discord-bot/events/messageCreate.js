const { Events, EmbedBuilder } = require("discord.js");
const config = require("../config.json");
const { getAfk, removeAfk, isAfk } = require("../utils/afkStore");

const LINK_REGEX = /(https?:\/\/[^\s]+)/gi;
const DISCORD_INVITE_REGEX = /(discord\.gg\/|discord\.com\/invite\/)/i;

function hasPermissionBypass(member, whitelistRoleIds) {
  if (!whitelistRoleIds || whitelistRoleIds.length === 0) return false;
  return member.roles.cache.some((r) => whitelistRoleIds.includes(r.id));
}

async function deleteWithWarning(message, reason) {
  await message.delete().catch(() => {});
  const warn = await message.channel.send(`⚠️ ${message.author}, pesanmu dihapus: ${reason}`);
  setTimeout(() => warn.delete().catch(() => {}), 5000);
}

module.exports = {
  name: Events.MessageCreate,
  async execute(message) {
    if (message.author.bot || !message.guild) return;
    const member = message.member;

    // ── 1. Lepas status AFK kalau yang bersangkutan kirim pesan ──
    if (isAfk(message.author.id)) {
      removeAfk(message.author.id);
      message.reply({ content: "✅ Status AFK kamu dilepas. Selamat datang kembali!" }).then((m) => {
        setTimeout(() => m.delete().catch(() => {}), 4000);
      });
    }

    // ── 2. Notify kalau mention orang yang lagi AFK ──
    if (message.mentions.users.size > 0) {
      for (const [, user] of message.mentions.users) {
        const afk = getAfk(user.id);
        if (afk) {
          message.reply({ content: `💤 ${user.username} sedang AFK: ${afk.reason}` }).catch(() => {});
        }
      }
    }

    // Skip auto-moderasi kalau member punya Manage Messages (moderator)
    const isModerator = member.permissions.has("ManageMessages");
    if (isModerator) return;

    // ── 3. Anti kata tertentu ──
    if (config.antiKata.enabled && !hasPermissionBypass(member, config.antiKata.whitelistRoleIds)) {
      const lower = message.content.toLowerCase();
      const found = config.antiKata.bannedWords.find((w) => w && lower.includes(w.toLowerCase()));
      if (found) {
        return deleteWithWarning(message, "mengandung kata terlarang.");
      }
    }

    // ── 4. Anti promosi (invite server Discord lain) ──
    if (
      config.antiPromosi.enabled &&
      !config.antiPromosi.whitelistChannelIds.includes(message.channel.id) &&
      !hasPermissionBypass(member, config.antiPromosi.whitelistRoleIds) &&
      DISCORD_INVITE_REGEX.test(message.content)
    ) {
      return deleteWithWarning(message, "dilarang promosi/invite server lain di sini.");
    }

    // ── 5. Anti link ──
    if (
      config.antiLink.enabled &&
      !config.antiLink.whitelistChannelIds.includes(message.channel.id) &&
      !hasPermissionBypass(member, config.antiLink.whitelistRoleIds) &&
      LINK_REGEX.test(message.content)
    ) {
      const isAllowedDomain = config.antiLink.allowedDomains.some((domain) =>
        message.content.toLowerCase().includes(domain)
      );
      if (!isAllowedDomain) {
        return deleteWithWarning(message, "dilarang kirim link di sini.");
      }
    }
  },
};
