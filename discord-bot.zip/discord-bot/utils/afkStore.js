// Penyimpanan status AFK sederhana di memori (reset kalau bot restart).
// Kalau mau permanen, bisa diganti ke database/json file nanti.

const afkMap = new Map(); // key: userId, value: { reason, since }

function setAfk(userId, reason) {
  afkMap.set(userId, { reason: reason || "AFK", since: Date.now() });
}

function removeAfk(userId) {
  return afkMap.delete(userId);
}

function getAfk(userId) {
  return afkMap.get(userId);
}

function isAfk(userId) {
  return afkMap.has(userId);
}

module.exports = { setAfk, removeAfk, getAfk, isAfk };
