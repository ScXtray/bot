const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");
const config = require("../config.json");

const configPath = path.join(__dirname, "..", "config.json");

function save() {
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("badword")
    .setDescription("Kelola daftar kata terlarang (anti kata tertentu)")
    .addSubcommand((sub) =>
      sub
        .setName("tambah")
        .setDescription("Tambah kata ke daftar terlarang")
        .addStringOption((opt) => opt.setName("kata").setDescription("Kata yang mau diblokir").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("hapus")
        .setDescription("Hapus kata dari daftar terlarang")
        .addStringOption((opt) => opt.setName("kata").setDescription("Kata yang mau dihapus").setRequired(true))
    )
    .addSubcommand((sub) => sub.setName("list").setDescription("Lihat daftar kata terlarang"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === "tambah") {
      const kata = interaction.options.getString("kata").toLowerCase();
      if (config.antiKata.bannedWords.includes(kata)) {
        return interaction.reply({ content: `"${kata}" sudah ada di daftar.`, ephemeral: true });
      }
      config.antiKata.bannedWords.push(kata);
      save();
      return interaction.reply({ content: `✅ "${kata}" ditambahkan ke daftar kata terlarang.`, ephemeral: true });
    }

    if (sub === "hapus") {
      const kata = interaction.options.getString("kata").toLowerCase();
      config.antiKata.bannedWords = config.antiKata.bannedWords.filter((w) => w !== kata);
      save();
      return interaction.reply({ content: `✅ "${kata}" dihapus dari daftar kata terlarang.`, ephemeral: true });
    }

    if (sub === "list") {
      const list = config.antiKata.bannedWords.length ? config.antiKata.bannedWords.join(", ") : "(kosong)";
      return interaction.reply({ content: `📋 Daftar kata terlarang: ${list}`, ephemeral: true });
    }
  },
};
