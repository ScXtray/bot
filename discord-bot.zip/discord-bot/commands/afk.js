const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { setAfk } = require("../utils/afkStore");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("afk")
    .setDescription("Set status AFK kamu")
    .addStringOption((opt) =>
      opt.setName("alasan").setDescription("Alasan AFK").setRequired(false)
    ),

  async execute(interaction) {
    const reason = interaction.options.getString("alasan") || "AFK";
    setAfk(interaction.user.id, reason);

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setDescription(`💤 **${interaction.user.username}** sekarang AFK: ${reason}`);

    return interaction.reply({ embeds: [embed] });
  },
};
