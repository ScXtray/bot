const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Ban member dari server")
    .addUserOption((opt) =>
      opt.setName("user").setDescription("Member yang mau di-ban").setRequired(true)
    )
    .addStringOption((opt) =>
      opt.setName("alasan").setDescription("Alasan ban").setRequired(false)
    )
    .addIntegerOption((opt) =>
      opt
        .setName("hapus_pesan_hari")
        .setDescription("Hapus pesan user dalam berapa hari terakhir (0-7)")
        .setMinValue(0)
        .setMaxValue(7)
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const reason = interaction.options.getString("alasan") || "Tidak ada alasan";
    const deleteDays = interaction.options.getInteger("hapus_pesan_hari") || 0;

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (member && !member.bannable) {
      return interaction.reply({ content: "Aku tidak bisa ban member ini (role lebih tinggi atau tanpa izin).", ephemeral: true });
    }

    await interaction.guild.members.ban(target.id, {
      reason,
      deleteMessageSeconds: deleteDays * 24 * 60 * 60,
    });

    const embed = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle("🔨 Member Di-ban")
      .addFields(
        { name: "User", value: `${target.tag}`, inline: true },
        { name: "Moderator", value: `${interaction.user.tag}`, inline: true },
        { name: "Alasan", value: reason }
      )
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
