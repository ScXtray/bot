const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");
const config = require("../config.json");

const configPath = path.join(__dirname, "..", "config.json");

function buildEmbed(guild) {
  const lines = Object.entries(config.reactRole.emojiRoleMap).map(([emoji, roleId]) => {
    const role = guild.roles.cache.get(roleId);
    return `${emoji} — ${role ? role.toString() : "*(role belum di-set di config.json)*"}`;
  });

  return new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle("🎭 Pilih Role")
    .setDescription("React emoji di bawah ini untuk dapat/lepas role.\n\n" + lines.join("\n"));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("reactrole")
    .setDescription("Kirim pesan react-role baru di channel ini (sesuai emojiRoleMap di config.json)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction) {
    const embed = buildEmbed(interaction.guild);
    const message = await interaction.channel.send({ embeds: [embed] });

    for (const emoji of Object.keys(config.reactRole.emojiRoleMap)) {
      await message.react(emoji).catch(() => {});
    }

    // Simpan messageId & channelId ke config.json biar event handler tahu pesan mana yang dipantau
    config.reactRole.messageId = message.id;
    config.reactRole.channelId = interaction.channel.id;
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));

    return interaction.reply({ content: "✅ Pesan react-role berhasil dibuat.", ephemeral: true });
  },
  buildEmbed,
};
