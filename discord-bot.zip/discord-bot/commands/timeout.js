const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");

// "TO" / timeout native Discord: otomatis lepas sendiri setelah durasi habis
module.exports = {
  data: new SlashCommandBuilder()
    .setName("to")
    .setDescription("Timeout member (otomatis lepas sendiri setelah durasi habis)")
    .addUserOption((opt) =>
      opt.setName("user").setDescription("Member yang mau di-timeout").setRequired(true)
    )
    .addIntegerOption((opt) =>
      opt
        .setName("menit")
        .setDescription("Durasi timeout dalam menit (max 40320 = 28 hari)")
        .setMinValue(1)
        .setMaxValue(40320)
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt.setName("alasan").setDescription("Alasan timeout").setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const minutes = interaction.options.getInteger("menit");
    const reason = interaction.options.getString("alasan") || "Tidak ada alasan";
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: "Member tidak ditemukan di server ini.", ephemeral: true });
    }
    if (!member.moderatable) {
      return interaction.reply({ content: "Aku tidak bisa timeout member ini.", ephemeral: true });
    }

    await member.timeout(minutes * 60 * 1000, reason);

    const embed = new EmbedBuilder()
      .setColor(0xffff00)
      .setTitle("⏳ Member Di-timeout")
      .addFields(
        { name: "User", value: `${target.tag}`, inline: true },
        { name: "Durasi", value: `${minutes} menit`, inline: true },
        { name: "Moderator", value: `${interaction.user.tag}`, inline: true },
        { name: "Alasan", value: reason }
      )
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
