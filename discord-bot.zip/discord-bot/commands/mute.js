const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const config = require("../config.json");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("mute")
    .setDescription("Mute member pakai role Muted (permanen sampai di-unmute manual)")
    .addUserOption((opt) =>
      opt.setName("user").setDescription("Member yang mau di-mute").setRequired(true)
    )
    .addStringOption((opt) =>
      opt.setName("alasan").setDescription("Alasan mute").setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const reason = interaction.options.getString("alasan") || "Tidak ada alasan";
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: "Member tidak ditemukan di server ini.", ephemeral: true });
    }

    let muteRole = interaction.guild.roles.cache.find((r) => r.name === config.muteRoleName);
    if (!muteRole) {
      // Bikin role Muted otomatis kalau belum ada
      muteRole = await interaction.guild.roles.create({
        name: config.muteRoleName,
        color: "Grey",
        reason: "Role otomatis untuk fitur mute",
      });
      // Set permission overwrite di semua channel biar role ini gak bisa kirim pesan
      interaction.guild.channels.cache.forEach(async (channel) => {
        await channel.permissionOverwrites
          .create(muteRole, { SendMessages: false, AddReactions: false, Speak: false })
          .catch(() => {});
      });
    }

    if (member.roles.cache.has(muteRole.id)) {
      return interaction.reply({ content: `${target.tag} sudah di-mute.`, ephemeral: true });
    }

    await member.roles.add(muteRole, reason);

    const embed = new EmbedBuilder()
      .setColor(0x808080)
      .setTitle("🔇 Member Di-mute")
      .addFields(
        { name: "User", value: `${target.tag}`, inline: true },
        { name: "Moderator", value: `${interaction.user.tag}`, inline: true },
        { name: "Alasan", value: reason }
      )
      .setFooter({ text: "Pakai /unmute untuk melepas mute" })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
