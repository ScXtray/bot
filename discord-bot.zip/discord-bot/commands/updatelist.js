const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const config = require("../config.json");
const { buildEmbed } = require("./reactrole");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("updatelist")
    .setDescription("Refresh tampilan pesan react-role (dipanggil setelah ubah config.json)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction) {
    const { messageId, channelId, emojiRoleMap } = config.reactRole;

    if (!messageId || !channelId) {
      return interaction.reply({
        content: "Belum ada pesan react-role. Pakai `/reactrole` dulu buat bikin baru.",
        ephemeral: true,
      });
    }

    const channel = await interaction.guild.channels.fetch(channelId).catch(() => null);
    const message = channel ? await channel.messages.fetch(messageId).catch(() => null) : null;

    if (!message) {
      return interaction.reply({
        content: "Pesan react-role lama tidak ditemukan (mungkin sudah dihapus). Pakai `/reactrole` buat bikin baru.",
        ephemeral: true,
      });
    }

    const embed = buildEmbed(interaction.guild);
    await message.edit({ embeds: [embed] });

    // Sinkronkan reaksi: hapus reaksi lama, pasang ulang sesuai config.json terbaru
    await message.reactions.removeAll().catch(() => {});
    for (const emoji of Object.keys(emojiRoleMap)) {
      await message.react(emoji).catch(() => {});
    }

    return interaction.reply({ content: "✅ List react-role berhasil di-update.", ephemeral: true });
  },
};
