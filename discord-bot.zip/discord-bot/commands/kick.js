const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kick member dari server")
    .addUserOption((opt) =>
      opt.setName("user").setDescription("Member yang mau di-kick").setRequired(true)
    )
    .addStringOption((opt) =>
      opt.setName("alasan").setDescription("Alasan kick").setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const reason = interaction.options.getString("alasan") || "Tidak ada alasan";
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: "Member tidak ditemukan di server ini.", ephemeral: true });
    }
    if (!member.kickable) {
      return interaction.reply({ content: "Aku tidak bisa kick member ini (role lebih tinggi atau tanpa izin).", ephemeral: true });
    }

    await member.kick(reason);

    const embed = new EmbedBuilder()
      .setColor(0xffa500)
      .setTitle("👢 Member Di-kick")
      .addFields(
        { name: "User", value: `${target.tag}`, inline: true },
        { name: "Moderator", value: `${interaction.user.tag}`, inline: true },
        { name: "Alasan", value: reason }
      )
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
