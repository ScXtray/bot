const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const config = require("../config.json");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("unmute")
    .setDescription("Lepas mute member")
    .addUserOption((opt) =>
      opt.setName("user").setDescription("Member yang mau di-unmute").setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    const muteRole = interaction.guild.roles.cache.find((r) => r.name === config.muteRoleName);

    if (!member || !muteRole || !member.roles.cache.has(muteRole.id)) {
      return interaction.reply({ content: `${target.tag} sedang tidak di-mute.`, ephemeral: true });
    }

    await member.roles.remove(muteRole);

    const embed = new EmbedBuilder()
      .setColor(0x00ff00)
      .setTitle("🔊 Mute Dilepas")
      .addFields(
        { name: "User", value: `${target.tag}`, inline: true },
        { name: "Moderator", value: `${interaction.user.tag}`, inline: true }
      )
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
